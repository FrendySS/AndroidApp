package com.example.animeviewer.domain.models

data class AnimeModel(
    val id: String,
    val title: String,
    val description: String
)
