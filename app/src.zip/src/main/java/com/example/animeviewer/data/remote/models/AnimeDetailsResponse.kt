package com.example.animeviewer.data.remote.models

data class AnimeDetailsResponse(
    val data: AnimeDto
)